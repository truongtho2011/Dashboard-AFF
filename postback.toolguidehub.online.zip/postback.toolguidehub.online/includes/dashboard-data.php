<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CAMPAIGN FILTER
|--------------------------------------------------------------------------
| $from / $to phải được set trước khi include file này (xem dashboard.php)
*/

$campaignFilter = $_GET['campaign'] ?? '';

$conditions = [
    "sales_time BETWEEN :from AND :to"
];

$params = [
    ':from' => $from,
    ':to'   => $to,
];

if ($campaignFilter !== '') {

    $conditions[] = "
        COALESCE(NULLIF(utm_campaign, ''), '(Không có campaign)')
        = :campaign
    ";

    $params[':campaign'] = $campaignFilter;
}

$where = implode(' AND ', $conditions);

/*
|--------------------------------------------------------------------------
| SUMMARY
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT

        COUNT(DISTINCT transaction_id) AS orders,

        COALESCE(
            SUM(product_price),
            0
        ) AS sales,

        COALESCE(
            SUM(reward),
            0
        ) AS commission,

        COALESCE(
            SUM(product_price)
            /
            NULLIF(COUNT(DISTINCT transaction_id), 0),
            0
        ) AS avg_order

    FROM at_conversions

    WHERE {$where}
");

$stmt->execute($params);

$summary = $stmt->fetch();

/*
|--------------------------------------------------------------------------
| DAILY CONVERSION
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT

        DATE(sales_time) AS conversion_date,

        COUNT(DISTINCT transaction_id) AS orders,

        COALESCE(SUM(product_price), 0) AS sales,

        COALESCE(SUM(reward), 0) AS commission

    FROM at_conversions

    WHERE {$where}

    GROUP BY DATE(sales_time)

    ORDER BY conversion_date ASC
");

$stmt->execute($params);

$daily = $stmt->fetchAll();

/*
|--------------------------------------------------------------------------
| MERCHANT PERFORMANCE
|--------------------------------------------------------------------------
| Luôn tính theo khoảng ngày (không áp merchant filter), vì bảng này
| dùng để hiển thị TOÀN BỘ danh sách merchant cho người dùng chọn/so sánh.
*/

$stmt = $pdo->prepare("
    SELECT
        COALESCE(
            NULLIF(merchant, ''),
            '(Không có merchant)'
        ) AS merchant,
        COUNT(DISTINCT transaction_id) AS orders,
        COALESCE(SUM(product_price), 0) AS sales,
        COALESCE(SUM(reward), 0) AS commission
    FROM at_conversions
    WHERE sales_time BETWEEN :from AND :to
    GROUP BY
        COALESCE(
            NULLIF(merchant, ''),
            '(Không có merchant)'
        )
    ORDER BY commission DESC
    LIMIT 10
");

$stmt->execute([':from' => $from, ':to' => $to]);

$merchants = $stmt->fetchAll();

/*
|--------------------------------------------------------------------------
| STATUS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT

        status,

        COUNT(DISTINCT transaction_id) AS orders,

        COALESCE(
            SUM(product_price),
            0
        ) AS sales,

        COALESCE(
            SUM(reward),
            0
        ) AS commission

    FROM at_conversions

    WHERE {$where}

    GROUP BY status

    ORDER BY status
");

$stmt->execute($params);

$statusRows = $stmt->fetchAll();

$statusSummary = [

    1 => [
        'name'       => 'Approved',
        'orders'     => 0,
        'sales'      => 0,
        'commission' => 0,
        'class'      => 'approved',
    ],

    0 => [
        'name'       => 'Pending',
        'orders'     => 0,
        'sales'      => 0,
        'commission' => 0,
        'class'      => 'pending',
    ],

    2 => [
        'name'       => 'Rejected',
        'orders'     => 0,
        'sales'      => 0,
        'commission' => 0,
        'class'      => 'rejected',
    ],
];

foreach ($statusRows as $row) {

    $status = (int)$row['status'];

    if (!isset($statusSummary[$status])) {
        continue;
    }

    $statusSummary[$status]['orders'] =
        (int)$row['orders'];

    $statusSummary[$status]['sales'] =
        (float)$row['sales'];

    $statusSummary[$status]['commission'] =
        (float)$row['commission'];
}

/*
|--------------------------------------------------------------------------
| RECENT CONVERSIONS
|--------------------------------------------------------------------------
| Giữ đủ cột (order_id, merchant, product_id, quantity, is_confirmed,
| confirmed_date) vì giao diện Recent Conversions hiện tại cần các cột này.
*/

$stmt = $pdo->prepare("
    SELECT
        id,
        transaction_id,
        order_id,
        merchant,
        product_id,
        product_category,
        quantity,
        product_price,
        reward,
        sales_time,
        status,
        is_confirmed,
        confirmed_date
    FROM at_conversions
    WHERE {$where}
    ORDER BY sales_time DESC
    LIMIT 10
");

$stmt->execute($params);

$recent = $stmt->fetchAll();

/*
|--------------------------------------------------------------------------
| CAMPAIGN LIST
|--------------------------------------------------------------------------
| Dùng biến $campaignList để đổ vào thẻ <select> trên giao diện
*/

$stmt = $pdo->query("
    SELECT DISTINCT

        COALESCE(
            NULLIF(utm_campaign, ''),
            '(Không có campaign)'
        ) AS campaign

    FROM at_conversions

    ORDER BY campaign ASC
");

$campaignList = $stmt->fetchAll();