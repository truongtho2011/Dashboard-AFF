<?php

declare(strict_types=1);

$config = require __DIR__ . '/../config.php';

try {

    $pdo = new PDO(
        'mysql:host=' . $config['db_host'] .
        ';dbname=' . $config['db_name'] .
        ';charset=utf8mb4',

        $config['db_user'],
        $config['db_pass'],

        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

} catch (Throwable $e) {

    http_response_code(500);

    die('Database connection error.');

}