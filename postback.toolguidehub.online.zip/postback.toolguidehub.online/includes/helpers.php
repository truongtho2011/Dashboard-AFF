<?php

declare(strict_types=1);

function money($value): string
{
    return number_format((float)$value, 0, ',', '.');
}


function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}


function statusLabel($status): string
{
    return match ((int)$status) {

        1 => '<span class="status approved">Approved</span>',

        2 => '<span class="status rejected">Rejected</span>',

        0 => '<span class="status pending">Pending</span>',

        default => '<span class="status">Unknown</span>',
    };
}