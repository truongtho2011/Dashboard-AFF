document.addEventListener('DOMContentLoaded', function () {
const syncButton = document.getElementById('syncATButton');
const syncResult = document.getElementById('syncResult');

if (!syncButton) return;

syncButton.addEventListener('click', async function () {
syncButton.disabled = true;
syncButton.textContent = '⟳ Đang đồng bộ...';

syncResult.textContent = '';
syncResult.className = 'sync-result';

try {
const response = await fetch('at-sync.php', {
method: 'GET',
cache: 'no-store'
});

const data = await response.json();

if (!response.ok || !data.success) {
throw new Error(data.message || 'Đồng bộ thất bại');
}

syncResult.className = 'sync-result sync-success';
syncResult.textContent =
`✓ ${data.received} giao dịch | ` +
`+${data.inserted} mới | ` +
`↻${data.updated} cập nhật`;

/*
* Đợi 1.2s rồi reload Dashboard để cập nhật dữ liệu
*/
setTimeout(() => {
window.location.reload();
}, 1200);

} catch (error) {
syncResult.className = 'sync-result sync-error';
syncResult.textContent = '✕ ' + error.message;

syncButton.disabled = false;
syncButton.textContent = '↻ Đồng bộ AT';
}
});
});