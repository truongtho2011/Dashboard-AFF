<?php

declare(strict_types=1);

require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/helpers.php';

/*
|--------------------------------------------------------------------------
| GET TRANSACTION ID
|--------------------------------------------------------------------------
*/

$transactionId = trim((string)($_GET['id'] ?? ''));

if ($transactionId === '') {
    http_response_code(400);
    die('Thiếu transaction ID.');
}


/*
|--------------------------------------------------------------------------
| DATABASE
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare("
        SELECT *
        FROM at_conversions
        WHERE transaction_id = :transaction_id
        LIMIT 1
    ");

    $stmt->execute([
        ':transaction_id' => $transactionId
    ]);

    $conversion = $stmt->fetch();

} catch (Throwable $e) {

    http_response_code(500);
    die('Không thể truy vấn dữ liệu.');

}


/*
|--------------------------------------------------------------------------
| NOT FOUND
|--------------------------------------------------------------------------
*/

if (!$conversion) {

    http_response_code(404);

    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Conversion không tồn tại</title>

        <link rel="stylesheet" href="assets/dashboard.css">
    </head>

    <body>

    <div class="container">

        <div class="section">

            <h2>Không tìm thấy conversion</h2>

            <p>
                Không tìm thấy transaction:
                <strong><?= e($transactionId) ?></strong>
            </p>

            <p>
                <a href="dashboard.php">
                    ← Quay lại Dashboard
                </a>
            </p>

        </div>

    </div>

    </body>
    </html>

    <?php

    exit;
}


/*
|--------------------------------------------------------------------------
| RAW DATA
|--------------------------------------------------------------------------
*/

$rawData = [];

if (!empty($conversion['raw_data'])) {

    $decoded = json_decode(
        $conversion['raw_data'],
        true
    );

    if (is_array($decoded)) {
        $rawData = $decoded;
    }
}


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function displayValue($value): string
{
    if ($value === null || $value === '') {
        return '<span class="empty-value">—</span>';
    }

    return e($value);
}

function moneyValue($value): string
{
    if ($value === null || $value === '') {
        return '—';
    }

    return number_format(
        (float)$value,
        0,
        ',',
        '.'
    ) . ' ₫';
}

function statusBadge($status): string
{
    return match ((int)$status) {

        1 =>
            '<span class="status approved">Approved</span>',

        2 =>
            '<span class="status rejected">Rejected</span>',

        0 =>
            '<span class="status pending">Pending</span>',

        default =>
            '<span class="status">Unknown</span>',
    };
}

?>
<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    <?= e($transactionId) ?> - Conversion Detail
</title>

<link
    rel="stylesheet"
    href="assets/dashboard.css"
>

<style>

/*
|--------------------------------------------------------------------------
| CONVERSION DETAIL
|--------------------------------------------------------------------------
*/

.detail-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;

    margin-bottom: 25px;

}

.detail-header h1 {

    margin: 0;

    font-size: 25px;

}

.back-button {

    display: inline-block;

    padding: 9px 14px;

    background: white;

    border: 1px solid #d1d5db;

    border-radius: 7px;

    color: #374151;

    text-decoration: none;

    font-size: 14px;

}

.back-button:hover {

    background: #f9fafb;

}


/*
|--------------------------------------------------------------------------
| DETAIL GRID
|--------------------------------------------------------------------------
*/

.detail-grid {

    display: grid;

    grid-template-columns:
        repeat(2, minmax(0, 1fr));

    gap: 20px;

}


/*
|--------------------------------------------------------------------------
| INFO BOX
|--------------------------------------------------------------------------
*/

.info-box {

    background: white;

    border-radius: 12px;

    padding: 22px;

    box-shadow:
        0 2px 8px rgba(0,0,0,.05);

}

.info-box h2 {

    margin-top: 0;

    margin-bottom: 20px;

    font-size: 18px;

}

.info-row {

    display: grid;

    grid-template-columns:
        180px 1fr;

    gap: 15px;

    padding: 11px 0;

    border-bottom:
        1px solid #f0f0f0;

}

.info-row:last-child {

    border-bottom: 0;

}

.info-label {

    color: #6b7280;

    font-size: 13px;

}

.info-value {

    font-size: 14px;

    word-break: break-word;

}

.empty-value {

    color: #9ca3af;

}


/*
|--------------------------------------------------------------------------
| MONEY
|--------------------------------------------------------------------------
*/

.money {

    font-weight: 700;

}


/*
|--------------------------------------------------------------------------
| RAW JSON
|--------------------------------------------------------------------------
*/

.raw-section {

    margin-top: 20px;

}

.raw-json {

    background: #111827;

    color: #e5e7eb;

    padding: 20px;

    border-radius: 10px;

    overflow-x: auto;

    font-family:
        ui-monospace,
        SFMono-Regular,
        Menlo,
        Monaco,
        Consolas,
        monospace;

    font-size: 12px;

    line-height: 1.6;

    white-space: pre-wrap;

    word-break: break-word;

}


/*
|--------------------------------------------------------------------------
| STATUS
|--------------------------------------------------------------------------
*/

.status {

    display: inline-block;

    padding: 4px 9px;

    border-radius: 20px;

    font-size: 11px;

}

.approved {

    background: #dcfce7;

    color: #166534;

}

.rejected {

    background: #fee2e2;

    color: #991b1b;

}

.pending {

    background: #fef3c7;

    color: #92400e;

}


/*
|--------------------------------------------------------------------------
| RESPONSIVE
|--------------------------------------------------------------------------
*/

@media (max-width: 800px) {

    .detail-grid {

        grid-template-columns: 1fr;

    }

    .detail-header {

        align-items: flex-start;

        flex-direction: column;

    }

    .info-row {

        grid-template-columns: 1fr;

        gap: 5px;

    }

}

</style>

</head>


<body>

<div class="container">


<!-- =========================================================
     HEADER
========================================================= -->

<div class="detail-header">

    <div>

        <h1>
            Conversion Detail
        </h1>

        <p>
            Transaction:
            <strong><?= e($conversion['transaction_id']) ?></strong>
        </p>

    </div>


    <a
        href="dashboard.php"
        class="back-button"
    >
        ← Dashboard
    </a>

</div>



<!-- =========================================================
     BASIC INFORMATION
========================================================= -->

<div class="detail-grid">


<div class="info-box">

    <h2>
        Conversion Information
    </h2>


    <div class="info-row">

        <div class="info-label">
            Transaction ID
        </div>

        <div class="info-value">

            <strong>
                <?= displayValue(
                    $conversion['transaction_id']
                ) ?>
            </strong>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Order ID
        </div>

        <div class="info-value">

            <?= displayValue(
                $conversion['order_id']
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Merchant
        </div>

        <div class="info-value">

            <?= displayValue(
                $conversion['merchant']
                ?? null
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Campaign
        </div>

        <div class="info-value">

            <?= displayValue(
                $conversion['utm_campaign']
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Campaign ID
        </div>

        <div class="info-value">

            <?= displayValue(
                $conversion['campaign_id']
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Status
        </div>

        <div class="info-value">

            <?= statusBadge(
                $conversion['status']
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Confirmed
        </div>

        <div class="info-value">

            <?php if (
                (int)$conversion['is_confirmed'] === 1
            ): ?>

                <span class="status approved">
                    ✓ Confirmed
                </span>

            <?php else: ?>

                <span class="status pending">
                    Chưa xác nhận
                </span>

            <?php endif; ?>

        </div>

    </div>


</div>



<!-- =========================================================
     PRODUCT
========================================================= -->

<div class="info-box">

    <h2>
        Product & Revenue
    </h2>


    <div class="info-row">

        <div class="info-label">
            Product ID
        </div>

        <div class="info-value">

            <?= displayValue(
                $conversion['product_id']
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Product Category
        </div>

        <div class="info-value">

            <?= displayValue(
                $conversion['product_category']
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Quantity
        </div>

        <div class="info-value">

            <?= number_format(
                (int)($conversion['quantity'] ?? 0)
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Product Price
        </div>

        <div class="info-value money">

            <?= moneyValue(
                $conversion['product_price']
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Commission
        </div>

        <div class="info-value money">

            <?= moneyValue(
                $conversion['reward']
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Sales Time
        </div>

        <div class="info-value">

            <?= displayValue(
                $conversion['sales_time']
            ) ?>

        </div>

    </div>


    <div class="info-row">

        <div class="info-label">
            Confirmed Date
        </div>

        <div class="info-value">

            <?= displayValue(
                $conversion['confirmed_date']
            ) ?>

        </div>

    </div>


</div>


</div>



<!-- =========================================================
     TRACKING
========================================================= -->

<div class="info-box" style="margin-top:20px;">

    <h2>
        Tracking Information
    </h2>


    <div class="detail-grid">


        <div>


            <div class="info-row">

                <div class="info-label">
                    UTM Source
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['utm_source']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    UTM Medium
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['utm_medium']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    UTM Campaign
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['utm_campaign']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    UTM Content
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['utm_content']
                    ) ?>

                </div>

            </div>


        </div>


        <div>


            <div class="info-row">

                <div class="info-label">
                    Sub1
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['sub1']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    Sub2
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['sub2']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    Sub3
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['sub3']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    Sub4
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['sub4']
                    ) ?>

                </div>

            </div>


        </div>


    </div>

</div>



<!-- =========================================================
     CLICK INFORMATION
========================================================= -->

<div class="info-box" style="margin-top:20px;">

    <h2>
        Click Information
    </h2>


    <div class="detail-grid">


        <div>


            <div class="info-row">

                <div class="info-label">
                    Click Time
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['click_time']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    Browser
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['browser']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    Conversion Platform
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['conversion_platform']
                    ) ?>

                </div>

            </div>


        </div>


        <div>


            <div class="info-row">

                <div class="info-label">
                    IP
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['ip']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    Referrer
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['referrer']
                    ) ?>

                </div>

            </div>


            <div class="info-row">

                <div class="info-label">
                    Received At
                </div>

                <div class="info-value">

                    <?= displayValue(
                        $conversion['received_at']
                    ) ?>

                </div>

            </div>


        </div>


    </div>

</div>



<!-- =========================================================
     RAW DATA
========================================================= -->

<div class="info-box raw-section">

    <h2>
        Raw AccessTrade Data
    </h2>


    <?php if (!empty($rawData)): ?>

        <pre class="raw-json"><?= e(
            json_encode(
                $rawData,
                JSON_PRETTY_PRINT |
                JSON_UNESCAPED_UNICODE |
                JSON_UNESCAPED_SLASHES
            )
        ) ?></pre>

    <?php else: ?>

        <p>
            Không có raw data.
        </p>

    <?php endif; ?>

</div>


</div>

</body>
</html>