<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

$config = require __DIR__ . '/config.php';

/*
|--------------------------------------------------------------------------
| CẤU HÌNH & XÁC ĐỊNH KHOẢNG THỜI GIAN
|--------------------------------------------------------------------------
*/

$defaultDays = 3;

$from = $_GET['from'] ?? null;
$to   = $_GET['to']   ?? null;

try {
    if ($from && $to) {
        $fromDate = new DateTime($from . ' 00:00:00', new DateTimeZone('UTC'));
        $toDate   = new DateTime($to . ' 23:59:59', new DateTimeZone('UTC'));
    } else {
        $toDate   = new DateTime('now', new DateTimeZone('UTC'));
        $fromDate = clone $toDate;
        $fromDate->modify("-{$defaultDays} days");
    }
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid date format',
        'example' => 'at-sync.php?from=2026-07-01&to=2026-07-31',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$since  = $fromDate->format('Y-m-d\TH:i:s\Z');
$until  = $toDate->format('Y-m-d\TH:i:s\Z');
$apiUrl = 'https://api.accesstrade.vn/v1/transactions';

$page          = 1;
$limit         = 100;
$totalReceived = 0;
$inserted      = 0;
$updated       = 0;
$skipped       = 0;

/*
|--------------------------------------------------------------------------
| KẾT NỐI DATABASE
|--------------------------------------------------------------------------
*/

try {
    $pdo = new PDO(
        'mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4',
        $config['db_user'],
        $config['db_pass'],
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database connection error',
        'error'   => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/*
|--------------------------------------------------------------------------
| PREPARE STATEMENTS
|--------------------------------------------------------------------------
*/

$check = $pdo->prepare("SELECT id FROM at_conversions WHERE transaction_id = :transaction_id LIMIT 1");

$insert = $pdo->prepare("
    INSERT INTO at_conversions (
        transaction_id, order_id, campaign_id, merchant, product_id, quantity,
        product_category, product_price, reward, sales_time, browser,
        conversion_platform, status, ip, referrer, click_time, is_confirmed,
        utm_source, utm_medium, utm_campaign, utm_content,
        sub1, sub2, sub3, sub4, customer_type, confirmed_date, raw_data
    ) VALUES (
        :transaction_id, :order_id, :campaign_id, :merchant, :product_id, :quantity,
        :product_category, :product_price, :reward, :sales_time, :browser,
        :conversion_platform, :status, :ip, :referrer, :click_time, :is_confirmed,
        :utm_source, :utm_medium, :utm_campaign, :utm_content,
        :sub1, :sub2, :sub3, :sub4, :customer_type, :confirmed_date, :raw_data
    )
");

$update = $pdo->prepare("
    UPDATE at_conversions SET
        order_id = :order_id, campaign_id = :campaign_id, merchant = :merchant,
        product_id = :product_id, quantity = :quantity, product_category = :product_category,
        product_price = :product_price, reward = :reward, sales_time = :sales_time,
        browser = :browser, conversion_platform = :conversion_platform, status = :status,
        ip = :ip, referrer = :referrer, click_time = :click_time, is_confirmed = :is_confirmed,
        utm_source = :utm_source, utm_medium = :utm_medium, utm_campaign = :utm_campaign,
        utm_content = :utm_content, sub1 = :sub1, sub2 = :sub2, sub3 = :sub3, sub4 = :sub4,
        customer_type = :customer_type, confirmed_date = :confirmed_date, raw_data = :raw_data
    WHERE transaction_id = :transaction_id
");

/*
|--------------------------------------------------------------------------
| HELPER FUNCTIONS
|--------------------------------------------------------------------------
*/

function parseDateTime(?string $dateStr): ?string {
    if (!$dateStr) return null;
    try {
        $dt = new DateTime($dateStr);
        return $dt->format('Y-m-d H:i:s');
    } catch (Throwable) {
        return null;
    }
}

function getUtm(array $transaction, string $key): ?string {
    $utm = $transaction['_utm'] ?? [];
    if (!is_array($utm)) $utm = [];

    $value = $transaction[$key] ?? $transaction['_' . $key] ?? $utm[$key] ?? null;
    if ($value === null || is_array($value)) return null;

    $value = trim((string)$value);
    return $value === '' ? null : $value;
}

/*
|--------------------------------------------------------------------------
| LOOP PAGINATION
|--------------------------------------------------------------------------
*/

try {
    while (true) {
        $params = [
            'since' => $since,
            'until' => $until,
            'page'  => $page,
            'limit' => $limit,
        ];

        $url = $apiUrl . '?' . http_build_query($params);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Token ' . $config['at_token'],
                'Content-Type: application/json',
            ],
        ]);

        $response  = curl_exec($ch);
        $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false || $curlError) {
            throw new RuntimeException('CURL error: ' . $curlError);
        }

        if ($httpCode < 200 || $httpCode >= 300) {
            throw new RuntimeException('AccessTrade API HTTP ' . $httpCode . ': ' . $response);
        }

        $json = json_decode($response, true);
        if (!is_array($json)) {
            throw new RuntimeException('Invalid JSON response');
        }

        $transactions = $json['data'] ?? [];
        if (!is_array($transactions) || empty($transactions)) {
            break;
        }

        foreach ($transactions as $transaction) {
            $totalReceived++;

            if (!is_array($transaction)) {
                $skipped++;
                continue;
            }

            $transactionId = $transaction['transaction_id'] ?? null;
            if (!$transactionId) {
                $skipped++;
                continue;
            }

            // Parse UTMs
            $utmSource   = getUtm($transaction, 'utm_source');
            $utmMedium   = getUtm($transaction, 'utm_medium');
            $utmCampaign = getUtm($transaction, 'utm_campaign');
            $utmContent  = getUtm($transaction, 'utm_content');

            // Parse Sub Params
            $subParams = $transaction['_extra']['sub_params'] ?? [];
            if (!is_array($subParams)) $subParams = [];

            $sub1 = $transaction['sub1'] ?? $subParams['sub1'] ?? null;
            $sub2 = $transaction['sub2'] ?? $subParams['sub2'] ?? null;
            $sub3 = $transaction['sub3'] ?? $subParams['sub3'] ?? null;
            $sub4 = $transaction['sub4'] ?? $subParams['sub4'] ?? null;

            // Extra details
            $browser       = $transaction['_extra']['browser'] ?? $transaction['browser'] ?? null;
            $confirmedDate = $transaction['confirmed_time'] ?? $transaction['confirmed_date'] ?? null;

            $rawData = json_encode(
                $transaction,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR
            );

            $values = [
                ':transaction_id'      => $transactionId,
                ':order_id'            => $transaction['order_id'] ?? $transactionId,
                ':campaign_id'         => $transaction['campaign_id'] ?? $transaction['campaign_no'] ?? null,
                ':merchant'            => $transaction['merchant'] ?? null,
                ':product_id'          => $transaction['product_id'] ?? null,
                ':quantity'            => isset($transaction['product_quantity']) ? (int)$transaction['product_quantity'] : (isset($transaction['quantity']) ? (int)$transaction['quantity'] : 1),
                ':product_category'    => $transaction['product_category'] ?? null,
                ':product_price'       => $transaction['product_price'] ?? $transaction['transaction_value'] ?? 0,
                ':reward'              => $transaction['commission'] ?? $transaction['reward'] ?? 0,
                ':sales_time'          => parseDateTime($transaction['transaction_time'] ?? $transaction['sales_time'] ?? null),
                ':browser'             => $browser,
                ':conversion_platform' => $transaction['conversion_platform'] ?? null,
                ':status'              => $transaction['status'] ?? 0,
                ':ip'                  => $transaction['ip'] ?? null,
                ':referrer'            => $transaction['referrer'] ?? null,
                ':click_time'          => parseDateTime($transaction['click_time'] ?? null),
                ':is_confirmed'        => $transaction['is_confirmed'] ?? 0,
                ':utm_source'          => $utmSource,
                ':utm_medium'          => $utmMedium,
                ':utm_campaign'        => $utmCampaign,
                ':utm_content'         => $utmContent,
                ':sub1'                => $sub1,
                ':sub2'                => $sub2,
                ':sub3'                => $sub3,
                ':sub4'                => $sub4,
                ':customer_type'       => $transaction['customer_type'] ?? null,
                ':confirmed_date'      => parseDateTime($confirmedDate),
                ':raw_data'            => $rawData,
            ];

            // Execute DB
            $check->execute([':transaction_id' => $transactionId]);
            $existing = $check->fetch();

            if ($existing) {
                $update->execute($values);
                $updated++;
            } else {
                $insert->execute($values);
                $inserted++;
            }
        }

        if (count($transactions) < $limit) {
            break;
        }

        $page++;
    }

    echo json_encode([
        'success'         => true,
        'message'         => 'AccessTrade synchronization completed',
        'period'          => ['since' => $since, 'until' => $until],
        'pages_processed' => $page,
        'received'        => $totalReceived,
        'inserted'        => $inserted,
        'updated'         => $updated,
        'skipped'         => $skipped,
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Synchronization failed',
        'error'   => $e->getMessage(),
        'page'    => $page,
        'period'  => ['since' => $since, 'until' => $until],
    ], JSON_UNESCAPED_UNICODE);
}