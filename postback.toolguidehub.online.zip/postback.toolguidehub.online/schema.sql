CREATE TABLE at_conversions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

    transaction_id VARCHAR(100) DEFAULT NULL,
    order_id VARCHAR(255) DEFAULT NULL,
    campaign_id VARCHAR(100) DEFAULT NULL,
    product_id VARCHAR(255) DEFAULT NULL,
    quantity INT DEFAULT NULL,
    product_category VARCHAR(255) DEFAULT NULL,
    product_price DECIMAL(15,2) DEFAULT NULL,
    reward DECIMAL(15,2) DEFAULT NULL,

    sales_time DATETIME DEFAULT NULL,
    browser VARCHAR(255) DEFAULT NULL,
    conversion_platform VARCHAR(100) DEFAULT NULL,

    status TINYINT DEFAULT NULL,
    ip VARCHAR(100) DEFAULT NULL,
    referrer TEXT DEFAULT NULL,
    click_time DATETIME DEFAULT NULL,

    is_confirmed TINYINT DEFAULT NULL,

    utm_source VARCHAR(255) DEFAULT NULL,
    utm_medium VARCHAR(255) DEFAULT NULL,
    utm_campaign VARCHAR(255) DEFAULT NULL,
    utm_content VARCHAR(255) DEFAULT NULL,

    sub1 VARCHAR(500) DEFAULT NULL,
    sub2 VARCHAR(500) DEFAULT NULL,
    sub3 VARCHAR(500) DEFAULT NULL,
    sub4 VARCHAR(500) DEFAULT NULL,

    customer_type VARCHAR(255) DEFAULT NULL,
    confirmed_date VARCHAR(100) DEFAULT NULL,

    raw_data LONGTEXT DEFAULT NULL,

    received_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_order_id (order_id),
    INDEX idx_campaign_id (campaign_id),
    INDEX idx_sub1 (sub1(100)),
    INDEX idx_status (status),
    INDEX idx_confirmed (is_confirmed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;