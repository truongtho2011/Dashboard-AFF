<?php 
return [     
    'db_host' => 'localhost',     
    'db_name' => 'vdgccyqlhosting_postback',     
    'db_user' => 'vdgccyqlhosting_postback',     
    'db_pass' => 'Abc@123456789', 
    'at_token' => 'aUtf1SYw-HHga3LAPXn7GybVToVdCtr1',
];