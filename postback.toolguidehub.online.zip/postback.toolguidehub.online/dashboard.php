<?php

declare(strict_types=1);

require __DIR__ . '/includes/db.php';
require __DIR__ . '/includes/helpers.php';

/*
|--------------------------------------------------------------------------
| DATE FILTER & QUICK RANGE LOGIC
|--------------------------------------------------------------------------
*/

$preset = $_GET['preset'] ?? '';
$action = $_GET['action'] ?? '';

// 1. Xử lý bộ lọc nhanh (Preset)
if ($preset !== '') {
    switch ($preset) {
        case 'today':
            $startDate = date('Y-m-d');
            $endDate   = date('Y-m-d');
            break;
        case 'yesterday':
            $startDate = date('Y-m-d', strtotime('-1 day'));
            $endDate   = date('Y-m-d', strtotime('-1 day'));
            break;
        case '7days':
            $startDate = date('Y-m-d', strtotime('-6 days'));
            $endDate   = date('Y-m-d');
            break;
        case '30days':
            $startDate = date('Y-m-d', strtotime('-29 days'));
            $endDate   = date('Y-m-d');
            break;
        case 'this_month':
            $startDate = date('Y-m-01');
            $endDate   = date('Y-m-t');
            break;
        case 'last_month':
            $startDate = date('Y-m-01', strtotime('first day of last month'));
            $endDate   = date('Y-m-t', strtotime('last day of last month'));
            break;
        default:
            $startDate = date('Y-m-d', strtotime('-29 days'));
            $endDate   = date('Y-m-d');
            break;
    }
} else {
    $startDate = $_GET['start'] ?? date('Y-m-d', strtotime('-29 days'));
    $endDate   = $_GET['end']   ?? date('Y-m-d');

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate)) {
        $startDate = date('Y-m-d', strtotime('-29 days'));
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate)) {
        $endDate = date('Y-m-d');
    }
}

// 2. Xử lý nút Tiến / Lùi khoảng ngày
if ($action === 'prev' || $action === 'next') {
    $startDt = new DateTime($startDate);
    $endDt   = new DateTime($endDate);
    
    // Tính số ngày trong khoảng hiện tại
    $diffDays = (int)$startDt->diff($endDt)->format('%a') + 1;
    $modifier = ($action === 'prev') ? "-{$diffDays} days" : "+{$diffDays} days";

    $startDt->modify($modifier);
    $endDt->modify($modifier);

    $startDate = $startDt->format('Y-m-d');
    $endDate   = $endDt->format('Y-m-d');
}

$from = $startDate . ' 00:00:00';
$to   = $endDate . ' 23:59:59';

/*
|--------------------------------------------------------------------------
| DATA (queries + $campaignFilter, $summary, $daily, $campaigns,
|       $merchants, $statusSummary, $recent)
|--------------------------------------------------------------------------
*/

require __DIR__ . '/includes/dashboard-data.php';

?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Affiliate Conversion Dashboard</title>
<link rel="stylesheet" href="assets/dashboard.css">
<style>
/* Style bổ sung cho Quick Filter & Navigation Buttons */
.filter-group {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px;
}
.btn-nav {
    padding: 6px 12px;
    background-color: #f3f4f6;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    color: #374151;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
}
.btn-nav:hover {
    background-color: #e5e7eb;
}
</style>
</head>

<body>

<div class="container">

<div class="header">

    <div>
        <h1>Affiliate Conversion Dashboard</h1>
        <p>AccessTrade Conversion Data</p>
    </div>

    <div class="sync-box">

        <button
            type="button"
            id="syncATButton"
            class="sync-button"
        >
            ↻ Đồng bộ AT
        </button>

        <span
            id="syncResult"
            class="sync-result"
        ></span>

    </div>

</div>

<!-- FILTER -->
<form class="filter" method="GET" style="display: flex; flex-direction: column; gap: 12px; align-items: flex-start; width: 100%;">

    <div class="filter-group" style="display: flex; flex-wrap: wrap; align-items: center; justify-content: flex-start; gap: 10px; width: 100%;">
        <!-- Nút Lùi Ngày -->
        <a 
            href="?start=<?= e($startDate) ?>&end=<?= e($endDate) ?>&action=prev" 
            class="btn-nav" 
            title="Lùi khoảng ngày"
        >
            ◄
        </a>

        <label>
            Từ ngày
            <input
                type="date"
                name="start"
                value="<?= e($startDate) ?>"
            >
        </label>

        <label>
            Đến ngày
            <input
                type="date"
                name="end"
                value="<?= e($endDate) ?>"
            >
        </label>

        <!-- Nút Tiến Ngày -->
        <a 
            href="?start=<?= e($startDate) ?>&end=<?= e($endDate) ?>&action=next" 
            class="btn-nav" 
            title="Tiến khoảng ngày"
        >
            ►
        </a>

        <label>
            Chọn nhanh
            <select name="preset" onchange="this.form.submit()">
                <option value="">-- Tùy chọn --</option>
                <option value="today" <?= $preset === 'today' ? 'selected' : '' ?>>Hôm nay</option>
                <option value="yesterday" <?= $preset === 'yesterday' ? 'selected' : '' ?>>Hôm qua</option>
                <option value="7days" <?= $preset === '7days' ? 'selected' : '' ?>>7 ngày qua</option>
                <option value="30days" <?= $preset === '30days' ? 'selected' : '' ?>>30 ngày qua</option>
                <option value="this_month" <?= $preset === 'this_month' ? 'selected' : '' ?>>Tháng này</option>
                <option value="last_month" <?= $preset === 'last_month' ? 'selected' : '' ?>>Tháng trước</option>
            </select>
        </label>

        <button type="submit">Xem dữ liệu</button>
    </div>

</form>

<!-- SUMMARY -->
<div class="cards">
    <div class="card">
        <div class="card-title">Orders</div>
        <div class="card-value"><?= number_format((int)($summary['orders'] ?? 0)) ?></div>
    </div>

    <div class="card">
        <div class="card-title">Sales</div>
        <div class="card-value"><?= money($summary['sales'] ?? 0) ?> ₫</div>
    </div>

    <div class="card">
        <div class="card-title">Commission</div>
        <div class="card-value"><?= money($summary['commission'] ?? 0) ?> ₫</div>
    </div>

    <div class="card">
        <div class="card-title">Avg Order (AOV)</div>
        <div class="card-value"><?= money($summary['avg_order'] ?? 0) ?> ₫</div>
    </div>
</div>

<!-- DAILY CHART -->
<div class="section">
    <h2>Conversion theo ngày</h2>

    <?php
    $maxOrders = 1;
    foreach ($daily as $row) {
        $maxOrders = max($maxOrders, (int)$row['orders']);
    }
    ?>

    <?php if (empty($daily)): ?>
        <p>Không có conversion trong khoảng thời gian này.</p>
    <?php else: ?>
        <div class="daily-chart">
            <?php foreach ($daily as $row): ?>
                <?php $height = ((int)$row['orders'] / $maxOrders) * 180; ?>
                <div class="bar-wrapper" title="<?= e($row['conversion_date']) ?> — <?= number_format((int)$row['orders']) ?> orders">
                    <div class="bar" style="height: <?= $height ?>px"></div>
                    <div class="bar-label"><?= date('d/m', strtotime($row['conversion_date'])) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- RECENT CONVERSIONS -->
<div class="section">
    <h2>Recent Conversions</h2>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Transaction</th>
                    <th>Order</th>
                    <th>Merchant</th>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Sales</th>
                    <th>Commission</th>
                    <th>Status</th>
                    <th>Confirmed</th>
                    <th>Time</th>
                </tr>
            </thead>

            <tbody>
            <?php if (empty($recent)): ?>
                <tr>
                    <td colspan="10">Không có conversion trong khoảng thời gian này.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($recent as $row): ?>
                    <tr>
                        <!-- TRANSACTION -->
                        <td>
                            <a
                                href="conversion.php?id=<?= urlencode($row['transaction_id']) ?>"
                                style="font-weight:700; color:#2563eb; text-decoration:none;"
                            >
                                <?= e($row['transaction_id']) ?>
                            </a>
                        </td>

                        <!-- ORDER -->
                        <td><?= e($row['order_id'] ?: '-') ?></td>

                        <!-- MERCHANT -->
                        <td><?= e($row['merchant'] ?: '-') ?></td>

                        <!-- PRODUCT -->
                        <td>
                            <?= e($row['product_category'] ?: $row['product_id'] ?: '-') ?>
                        </td>

                        <!-- QUANTITY -->
                        <td><?= number_format((int)($row['quantity'] ?? 0)) ?></td>

                        <!-- SALES -->
                        <td><strong><?= money($row['product_price']) ?> ₫</strong></td>

                        <!-- COMMISSION -->
                        <td><?= money($row['reward']) ?> ₫</td>

                        <!-- STATUS -->
                        <td><?= statusLabel($row['status']) ?></td>

                        <!-- CONFIRMED -->
                        <td>
                            <?php if ((int)$row['is_confirmed'] === 1): ?>
                                <span class="status approved">✓ Confirmed</span>
                            <?php else: ?>
                                <span class="status pending">Chưa xác nhận</span>
                            <?php endif; ?>
                        </td>

                        <!-- TIME -->
                        <td>
                            <?= !empty($row['sales_time']) ? date('d/m/Y H:i', strtotime($row['sales_time'])) : '-' ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- MERCHANT PERFORMANCE -->
<div class="section">
    <h2>Merchant Performance</h2>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Merchant</th>
                    <th>Orders</th>
                    <th>Sales</th>
                    <th>Commission</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($merchants)): ?>
                <tr>
                    <td colspan="4">Không có dữ liệu.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($merchants as $merchant): ?>
                    <tr>
                        <td>
                            <a
                                href="merchant-detail.php?merchant=<?= urlencode($merchant['merchant']) ?>&start=<?= e($startDate) ?>&end=<?= e($endDate) ?>"
                                class="campaign-link"
                            >
                                <strong><?= e($merchant['merchant']) ?></strong>
                            </a>
                        </td>
                        <td><?= number_format((int)$merchant['orders']) ?></td>
                        <td><?= money($merchant['sales']) ?> ₫</td>
                        <td><?= money($merchant['commission']) ?> ₫</td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- STATUS BREAKDOWN -->
<div class="section">
    <h2>Status Breakdown</h2>

    <div class="cards" style="margin-bottom: 0;">
        <?php foreach ($statusSummary as $stCode => $stData): ?>
            <div class="card" style="border-left: 4px solid <?= $stCode === 1 ? '#16a34a' : ($stCode === 2 ? '#dc2626' : '#d97706') ?>;">
                <div class="card-title">
                    <span class="status <?= $stData['class'] ?>"><?= $stData['name'] ?></span>
                </div>
                <div class="card-value" style="font-size: 22px;">
                    <?= number_format($stData['orders']) ?> <span style="font-size: 13px; font-weight: normal; color: #6b7280;">đơn</span>
                </div>
                <div style="margin-top: 8px; font-size: 13px; color: #4b5563;">
                    <div>Sales: <strong><?= money($stData['sales']) ?> ₫</strong></div>
                    <div>Hoa hồng: <strong><?= money($stData['commission']) ?> ₫</strong></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</div>

<!-- SCRIPT EMBED -->
<script src="assets/dashboard.js?v=<?= time() ?>"></script>
</body>
</html>